from django.apps import AppConfig


class ImpossibleTravelConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "impossible_travel"
